﻿using System.Security.Claims;
using System.Text.Json;
using FinanceCalculator.API.Contracts;
using FinanceCalculator.API.Data;
using FinanceCalculator.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceCalculator.API.Controllers
{

    [ApiController]
    [Authorize]
    [Route("api/leasing-goods")]
    public class LeasingGoodsCalculatorController :ControllerBase
    {
        private readonly ILeasingGoodsCalculatorService _service;
        private readonly AppDbContext _db;

        public LeasingGoodsCalculatorController(ILeasingGoodsCalculatorService service, AppDbContext db)
        {
            _service = service;
            _db = db;
        }

        [HttpPost("calculate")]
        public ActionResult<LeasingGoodsResponce>Calculate(
            [FromBody] LeasingGoodsRequest request)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var result = _service.Calculate(request);
            _db.CalculationRecords.Add(new CalculationRecord
            {
                CalculationType = "LeasingGoods",
                RequestJson = JsonSerializer.Serialize(request),
                ResponseJson = JsonSerializer.Serialize(result),
                UserId = userId
            });
            _db.SaveChanges();
            return Ok(result);
        }
    }
}
