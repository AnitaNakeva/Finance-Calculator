﻿using System.Security.Claims;
using System.Text.Json;
using FinanceCalculator.API.Contracts;
using FinanceCalculator.API.Data;
using FinanceCalculator.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceCalculator.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/refinance")]
    public class RefinanceCalculatorController : ControllerBase
    {
        private readonly IRefinanceCalculatorService _service;
        private readonly AppDbContext _db;

        public RefinanceCalculatorController(IRefinanceCalculatorService service, AppDbContext db)
        {
            _service = service;
            _db = db;
        }

        [HttpPost("calculate")]
        public ActionResult<RefinaceResponce> Calculate([FromBody] RefinanceRequest request)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var result = _service.Calculate(request);
            _db.CalculationRecords.Add(new CalculationRecord
            {
                CalculationType = "Refinance",
                RequestJson = JsonSerializer.Serialize(request),
                ResponseJson = JsonSerializer.Serialize(result),
                UserId = userId
            });
            _db.SaveChanges();
            return Ok(result);
        }
    }
}
