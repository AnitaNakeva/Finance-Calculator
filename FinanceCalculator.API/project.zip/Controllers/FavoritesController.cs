﻿using System.Security.Claims;
using FinanceCalculator.API.Data;
using FinanceCalculator.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinanceCalculator.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/calculations/favorites")]
    public class FavoritesController : ControllerBase
    {
        private readonly AppDbContext _db;

        public FavoritesController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<FavoriteCalculation>>> List()
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var items = await _db.FavoriteCalculations
                .Where(f => f.UserId == userId)
                .OrderBy(f => f.Name)
                .ToListAsync();

            return Ok(items);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] FavoriteRequest request)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            if (!request.HistoryId.HasValue)
                return BadRequest("historyId is required.");

            var record = await _db.CalculationRecords.FirstOrDefaultAsync(r => r.Id == request.HistoryId && r.UserId == userId);
            if (record == null) return NotFound("History item not found.");

            var calculationType = record.CalculationType;
            var requestJson = record.RequestJson;

            var name = string.IsNullOrWhiteSpace(request.Name)
                ? $"Favorite {calculationType} {DateTime.UtcNow:yyyyMMddHHmmss}"
                : request.Name.Trim();

            var exists = await _db.FavoriteCalculations.AnyAsync(f => f.UserId == userId && f.Name == name);
            if (exists) return Conflict("Favorite with that name already exists.");

            var favorite = new FavoriteCalculation
            {
                UserId = userId,
                Name = name,
                CalculationType = calculationType,
                RequestJson = requestJson,
                CreatedAtUtc = DateTime.UtcNow
            };

            _db.FavoriteCalculations.Add(favorite);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = favorite.Id }, favorite);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<FavoriteCalculation>> Get(int id)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var favorite = await _db.FavoriteCalculations.FirstOrDefaultAsync(f => f.Id == id && f.UserId == userId);
            if (favorite == null) return NotFound();

            return Ok(favorite);
        }

        [HttpPatch("{id:int}")]
        public async Task<IActionResult> Rename(int id, [FromBody] FavoriteRequest request)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            if (string.IsNullOrWhiteSpace(request.Name))
                return BadRequest("Name is required.");

            var favorite = await _db.FavoriteCalculations.FirstOrDefaultAsync(f => f.Id == id && f.UserId == userId);
            if (favorite == null) return NotFound();

            var newName = request.Name.Trim();
            var exists = await _db.FavoriteCalculations.AnyAsync(f => f.UserId == userId && f.Name == newName && f.Id != id);
            if (exists) return Conflict("Favorite with that name already exists.");

            favorite.Name = newName;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var favorite = await _db.FavoriteCalculations.FirstOrDefaultAsync(f => f.Id == id && f.UserId == userId);
            if (favorite == null) return NotFound();

            _db.FavoriteCalculations.Remove(favorite);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
