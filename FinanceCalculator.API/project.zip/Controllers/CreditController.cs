﻿using System.Security.Claims;
using System.Text.Json;
using FinanceCalculator.API.Contracts;
using FinanceCalculator.API.Data;
using FinanceCalculator.API.Models;
using FinanceCalculator.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FinanceCalculator.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/credit")]
    public class CreditController : ControllerBase
    {
        private readonly ICreditCalculatorService _service;
        private readonly AppDbContext _db;

        public CreditController(ICreditCalculatorService service, AppDbContext db)
        {
            _service = service;
            _db = db;
        }

        [HttpPost("calculate")]
        public IActionResult Calculate([FromBody] CreditRequest request)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var result = _service.Calculate(request);
            _db.CalculationRecords.Add(new CalculationRecord
            {
                CalculationType = "Credit",
                RequestJson = JsonSerializer.Serialize(request),
                ResponseJson = JsonSerializer.Serialize(result),
                UserId = userId
            });
            _db.SaveChanges();
            return Ok(result);
        }
    }
}
