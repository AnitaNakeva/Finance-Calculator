﻿using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using FinanceCalculator.API.Data;
using FinanceCalculator.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinanceCalculator.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/calculations")]
    public class CalculationHistoryController : ControllerBase
    {
        private readonly AppDbContext _db;

        public CalculationHistoryController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("history")]
        public async Task<ActionResult<CalculationHistoryResponse>> GetHistory(
            [FromQuery] string? calculationType,
            [FromQuery] DateTime? from,
            [FromQuery] DateTime? to,
            [FromQuery] string? search,
            [FromQuery] string sortOrder = "desc",
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 50)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 50;
            if (pageSize > 200) pageSize = 200;

            var query = BuildQuery(userId, calculationType, from, to, search);

            var total = await query.CountAsync();

            sortOrder = sortOrder.ToLowerInvariant();

            query = sortOrder == "asc"
                ? query.OrderBy(r => r.CreatedAtUtc)
                : query.OrderByDescending(r => r.CreatedAtUtc);

            var skip = (page - 1) * pageSize;

            var rawItems = await query
                .Skip(skip)
                .Take(pageSize)
                .Select(r => new CalculationHistoryItem
                {
                    Id = r.Id,
                    CalculationType = r.CalculationType,
                    RequestJson = r.RequestJson,
                    ResponseJson = r.ResponseJson,
                    CreatedAtUtc = r.CreatedAtUtc
                })
                .ToListAsync();

            var views = rawItems.Select(ToView).ToList();

            var response = new CalculationHistoryResponse
            {
                Page = page,
                PageSize = pageSize,
                TotalCount = total,
                TotalPages = (int)Math.Ceiling(total / (double)pageSize),
                Items = views
            };

            return Ok(response);
        }

        [HttpGet("history/export/csv")]
        public async Task<IActionResult> ExportCsv(
            [FromQuery] string? calculationType,
            [FromQuery] DateTime? from,
            [FromQuery] DateTime? to,
            [FromQuery] string? search)
        {
            var csv = await BuildCsv(calculationType, from, to, search);
            if (csv == null) return Unauthorized();
            return csv;
        }

        private async Task<FileContentResult?> BuildCsv(string? calculationType, DateTime? from, DateTime? to, string? search, string contentType = "text/csv", string fileName = "calculation-history.csv")
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return null;

            var query = BuildQuery(userId, calculationType, from, to, search)
                .OrderByDescending(r => r.CreatedAtUtc)
                .Take(5000); // safety cap

            var rows = await query
                .Select(r => new CalculationHistoryItem
                {
                    Id = r.Id,
                    CalculationType = r.CalculationType,
                    RequestJson = r.RequestJson,
                    ResponseJson = r.ResponseJson,
                    CreatedAtUtc = r.CreatedAtUtc
                })
                .ToListAsync();

            var sb = new StringBuilder();
            sb.AppendLine("Id,CalculationType,CreatedAtUtc,Principal,TermMonths,AnnualRate,PaymentType,MonthlyPayment,TotalPaid,TotalInterest");

            foreach (var r in rows)
            {
                var parsed = ParseDetails(r);
                sb.AppendLine(string.Join(",", new[]
                {
                    CsvEscape(r.Id.ToString()),
                    CsvEscape(r.CalculationType),
                    CsvEscape(r.CreatedAtUtc.ToString("o", CultureInfo.InvariantCulture)),
                    CsvEscape(parsed.Principal?.ToString("0.##") ?? string.Empty),
                    CsvEscape(parsed.TermMonths?.ToString() ?? string.Empty),
                    CsvEscape(parsed.AnnualRate?.ToString("0.##") ?? string.Empty),
                    CsvEscape(parsed.PaymentType ?? string.Empty),
                    CsvEscape(parsed.MonthlyPayment ?? string.Empty),
                    CsvEscape(parsed.TotalPaid?.ToString("0.##") ?? string.Empty),
                    CsvEscape(parsed.TotalInterest?.ToString("0.##") ?? string.Empty)
                }));
            }

            var bytes = Encoding.UTF8.GetBytes(sb.ToString());
            return File(bytes, contentType, fileName);
        }

        [HttpDelete("history/{id:int}")]
        public async Task<IActionResult> DeleteHistory(int id)
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized();

            var record = await _db.CalculationRecords.FirstOrDefaultAsync(r => r.Id == id && r.UserId == userId);
            if (record == null) return NotFound();

            _db.CalculationRecords.Remove(record);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        private IQueryable<CalculationRecord> BuildQuery(int userId, string? calculationType, DateTime? from, DateTime? to, string? search)
        {
            var query = _db.CalculationRecords.Where(r => r.UserId == userId);

            if (!string.IsNullOrWhiteSpace(calculationType))
            {
                var type = calculationType.Trim().ToLowerInvariant();
                query = query.Where(r => r.CalculationType.ToLower() == type);
            }

            if (from.HasValue)
            {
                query = query.Where(r => r.CreatedAtUtc >= from.Value);
            }

            if (to.HasValue)
            {
                query = query.Where(r => r.CreatedAtUtc <= to.Value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = $"%{search.Trim().ToLowerInvariant()}%";
                query = query.Where(r =>
                    EF.Functions.Like(r.RequestJson.ToLower(), term) ||
                    EF.Functions.Like(r.ResponseJson.ToLower(), term));
            }

            return query;
        }

        private string CsvEscape(string input)
        {
            if (input == null) return string.Empty;
            var needsQuotes = input.Contains(',') || input.Contains('"') || input.Contains('\n') || input.Contains('\r');
            var value = input.Replace("\"", "\"\"");
            return needsQuotes ? $"\"{value}\"" : value;
        }

        private CalculationHistoryView ToView(CalculationHistoryItem item)
        {
            var parsed = ParseDetails(item);

            return new CalculationHistoryView
            {
                Id = item.Id,
                CalculationType = item.CalculationType,
                CreatedAtUtc = item.CreatedAtUtc,
                Principal = parsed.Principal,
                TermMonths = parsed.TermMonths,
                AnnualRate = parsed.AnnualRate,
                PaymentType = parsed.PaymentType,
                MonthlyPayment = parsed.MonthlyPayment,
                TotalPaid = parsed.TotalPaid,
                TotalInterest = parsed.TotalInterest,
                FinancedAmount = parsed.FinancedAmount,
                OverpaymentPercent = parsed.OverpaymentPercent,
                Savings = parsed.Savings,
                CurrentCloseCost = parsed.CurrentCloseCost
            };
        }

        private ParsedCalculation ParseDetails(CalculationHistoryItem item)
        {
            var parsed = new ParsedCalculation { CalculationType = item.CalculationType, CreatedAtUtc = item.CreatedAtUtc };
            try
            {
                switch (item.CalculationType.ToLowerInvariant())
                {
                    case "credit":
                        var creditRequest = JsonSerializer.Deserialize<CreditRequest>(item.RequestJson);
                        var creditResponse = JsonSerializer.Deserialize<CreditResponse>(item.ResponseJson);
                        if (creditRequest != null && creditResponse != null)
                        {
                            parsed.Principal = creditRequest.Principal;
                            parsed.TermMonths = creditRequest.TermMonths;
                            parsed.AnnualRate = creditRequest.AnnualInterestRate;
                            parsed.PaymentType = creditRequest.PaymentType == PaymentType.Decreasing ? "Decreasing" : "Annuity";
                            parsed.MonthlyPayment = creditRequest.PaymentType == PaymentType.Decreasing
                                ? "Varies (decreasing)"
                                : creditResponse.MonthlyPayment.ToString("0.##");
                            parsed.TotalPaid = creditResponse.TotalPaid;
                            parsed.TotalInterest = creditResponse.TotalInterest;
                        }
                        break;
                    case "leasinggoods":
                        var leaseResponse = JsonSerializer.Deserialize<LeasingGoodsResponce>(item.ResponseJson);
                        if (leaseResponse != null)
                        {
                            parsed.FinancedAmount = leaseResponse.FinancedAmount;
                            parsed.TotalPaid = leaseResponse.TotalPaid;
                            parsed.OverpaymentPercent = leaseResponse.OverpaymentPercent;
                        }
                        break;
                    case "refinance":
                        var refiResponse = JsonSerializer.Deserialize<RefinaceResponce>(item.ResponseJson);
                        if (refiResponse != null)
                        {
                            parsed.MonthlyPayment = refiResponse.NewMonthlyPayment.ToString("0.##");
                            parsed.Savings = refiResponse.Savings;
                            parsed.CurrentCloseCost = refiResponse.CurrentTotalCostToClose;
                        }
                        break;
                }
            }
            catch
            {
                // ignore parsing errors
            }

            return parsed;
        }

        private string BuildSummary(ParsedCalculation parsed)
        {
            switch (parsed.CalculationType.ToLowerInvariant())
            {
                case "credit":
                    if (parsed.Principal.HasValue)
                    {
                        return $"Credit: principal {parsed.Principal}, term {parsed.TermMonths} mo, rate {parsed.AnnualRate}% | monthly {parsed.MonthlyPayment}, total paid {parsed.TotalPaid:0.##}, interest {parsed.TotalInterest:0.##}";
                    }
                    break;
                case "leasinggoods":
                    if (parsed.FinancedAmount.HasValue)
                    {
                        return $"Leasing: financed {parsed.FinancedAmount}, total paid {parsed.TotalPaid:0.##}, overpayment {parsed.OverpaymentPercent}%";
                    }
                    break;
                case "refinance":
                    if (parsed.Savings.HasValue)
                    {
                        return $"Refinance: new monthly {parsed.MonthlyPayment}, savings {parsed.Savings:0.##}, current close cost {parsed.CurrentCloseCost:0.##}";
                    }
                    break;
            }
            return "Details unavailable";
        }
    }
}
