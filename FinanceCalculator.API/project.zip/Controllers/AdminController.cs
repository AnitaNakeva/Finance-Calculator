﻿using System.Linq;
using System.Threading.Tasks;
using FinanceCalculator.API.Data;
using FinanceCalculator.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinanceCalculator.API.Controllers
{
    [ApiController]
    [Route("api/admin")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly AppDbContext _db;

        public AdminController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("users")]
        public async Task<ActionResult<IEnumerable<object>>> GetUsers()
        {
            var users = await _db.Users
                .OrderBy(u => u.Id)
                .Select(u => new { u.Id, u.Username, u.Role })
                .ToListAsync();
            return Ok(users);
        }

        [HttpPatch("users/{id}/role")]
        public async Task<IActionResult> ChangeRole(int id, [FromBody] ChangeRoleRequest request)
        {
            var user = await _db.Users.FindAsync(id);
            if (user == null) return NotFound();

            var role = request.Role?.Trim();
            if (role != "Admin" && role != "User") return BadRequest("Role must be Admin or User.");

            user.Role = role;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("calculations")]
        public async Task<ActionResult<IEnumerable<object>>> GetCalculations([FromQuery] int? userId)
        {
            var query = _db.CalculationRecords
                .Include(r => r.User)
                .OrderByDescending(r => r.CreatedAtUtc)
                .AsQueryable();

            if (userId.HasValue)
                query = query.Where(r => r.UserId == userId.Value);

            var items = await query
                .Take(100)
                .Select(r => new
                {
                    r.Id,
                    r.CalculationType,
                    r.UserId,
                    Username = r.User != null ? r.User.Username : string.Empty,
                    r.CreatedAtUtc
                })
                .ToListAsync();

            return Ok(items);
        }

        [HttpGet("audit")]
        public async Task<ActionResult<IEnumerable<object>>> GetAudit([FromQuery] int? userId)
        {
            var query = _db.AuditLogs
                .Include(a => a.User)
                .OrderByDescending(a => a.TimestampUtc)
                .AsQueryable();

            if (userId.HasValue)
                query = query.Where(a => a.UserId == userId.Value);

            var items = await query
                .Take(200)
                .Select(a => new
                {
                    a.Id,
                    a.UserId,
                    Username = a.User != null ? a.User.Username : string.Empty,
                    a.Event,
                    a.TimestampUtc,
                    a.IpAddress,
                    a.UserAgent
                })
                .ToListAsync();

            return Ok(items);
        }

        [HttpPost("cleanup")]
        public async Task<IActionResult> Cleanup([FromQuery] int days = 30)
        {
            var cutoff = DateTime.UtcNow.AddDays(-Math.Abs(days));

            var oldTokens = _db.RevokedTokens.Where(r => r.ExpiresAtUtc <= cutoff);
            if (oldTokens.Any()) _db.RevokedTokens.RemoveRange(oldTokens);

            var oldAudit = _db.AuditLogs.Where(a => a.TimestampUtc <= cutoff);
            if (oldAudit.Any()) _db.AuditLogs.RemoveRange(oldAudit);

            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
